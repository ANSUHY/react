# react-tabulator

React Tabulator

<em>[TODO.md spec & Kanban Board](https://marketplace.visualstudio.com/items?itemName=coddx.coddx-alpha)</em>

### Todo

- [ ] example for Add Row  
- [ ] add / generate more types  

### In Progress

- [ ] upgrade dependencies  
- [ ] fix: MultiSelectEditor is broken  

### Done ✓

- [x] use Github Action  
- [x] add more Codesandbox examples  
- [x] capture a GIF demo  
- [x] remove date-fns  
- [x] add TODO.md  
- [x] upgrade tabulator to 4.6.1  

