export default function (cell: any, formatterParams: any, onRendered: (fn: any) => void): HTMLDivElement;
