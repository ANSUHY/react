export declare function clone(obj: any): any;
export declare function isSameArray(a: any[], b: any[]): boolean;
export declare function isSameObject(a: any, b: any): boolean;
export declare function reactFormatter(JSX: any): (cell: any, formatterParams: any, onRendered: (callback: () => void) => void) => string;
