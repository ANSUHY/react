export default function (cell: any, onRendered: (fn: any) => void, success: (value: any) => void, cancel: () => void, editorParams?: any): HTMLDivElement;
