/// <reference types="react" />
declare const _default: () => JSX.Element;
export default _default;
