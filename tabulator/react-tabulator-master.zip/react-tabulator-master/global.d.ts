declare module 'pick-react-known-prop';
declare module 'tabulator-tables';