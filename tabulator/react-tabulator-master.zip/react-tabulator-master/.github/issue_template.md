**Title**
  - bug: XYZ broken...
  - feature: please add...
  - enhancement: add this to existing features...
  
**Environment Details**
  * react-tabulator version:
  * OS:
  * Node.js version:

**Long Description**
  - please add screenshot(s)
  - please add a Codesandbox link

```JS
JS code example goes here... (a Codesandbox link is preferred)
```

**Workaround**

...

(Please help with a PR if you have a solution. Thanks!)
