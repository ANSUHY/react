import 'src/css/layout/Footer.css';

function Page() {
    return (
        <div className="Footer MainGradient">

        </div>
    );
}

export default Page;
