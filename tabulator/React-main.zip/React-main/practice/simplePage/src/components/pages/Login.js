import CONST from 'src/assets/js/const';
import 'src/css/pages/Login.css';

function Login(props) {
    return (
        <div className="Login">{CONST.ROUTER.NAME.LOGIN}</div>
    )

}

export default Login;
