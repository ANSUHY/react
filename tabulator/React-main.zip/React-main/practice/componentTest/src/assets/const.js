const CONST = {
    TITLE: "WORDATA",
    INFO: {
        DESCRIPTION: "The ONE EPIC Word List only for YOU",
        PRICEPOLICY: "10,000$ FOR EACH ACCOUNT",
        COPYRIGHT: "All Rights Reserved. © 2019 EZIS for Colud",
        ADDRESS: "Seoul, Republic of Korea",
    },
    APPLICATION: {
        MAIN: {
            TRIAL: "Free Trial MODE",
            DEFAULT: "Default MODE",
        },
        BUTTONS: {
            TRIAL: "Free Trial",
            DEFAULT: "Default"
        },
        STATE: {
            TRIAL: "trial",
            DEFAULT: "default"
        }
    }
}

export default CONST