# React
## React self-study 

### 1. tic tac toe game

>practice code (source : [React tutorial](https://reactjs.org/tutorial/tutorial.html))  
>정리 : [리액트 초기세팅 및 실습 1차](https://kline1103.tistory.com/55?category=426769)

### 2. compnent test

>컴포넌트간 데이터 흐름 실습  
>props, state 및 이벤트   
>정리 : [리액트 초기세팅 및 실습 2차](https://kline1103.tistory.com/65?category=426769)    


### 3. simple page

>리액트로 프론트 페이지 구성  
>서드파티 라이브러리 사용  
>오픈 API 사용 및 CORS 프록시 설정  
>react-route-dom을 이용한 라우터 설정  
>정리 : [리액트 초기세팅 및 실습 3차](https://kline1103.tistory.com/67?category=426769) , [리액트 초기세팅 및 실습 4차](https://kline1103.tistory.com/69?category=426769), [리액트 초기세팅 및 실습 5차](https://kline1103.tistory.com/72?category=426769)  
